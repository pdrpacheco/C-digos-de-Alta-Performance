package Exercicio01;

import java.util.Scanner;

import Filas.FilaInt;

public class exercicio1 {

	public static void main(String[] args) {
		
		Scanner le = new Scanner(System.in);
		FilaInt fila = new FilaInt();
		fila.init();
		System.out.println("Digite valor positivo para enfileirar ou "
				+ "negativo para sair");
		int valor = le.nextInt();
		while(valor >= 0) {
			//insere na fila valor digitado
			fila.enqueue(valor);
			System.out.println("Digite valor positivo para enfileirar ou"
					+ "negativo para sair");
			valor = le.nextInt();
		}
		
		while(!fila.IsEmpty()) {
			System.out.println("Valor Retirado da fila: " +fila.dequeue());
		}

	}

}
