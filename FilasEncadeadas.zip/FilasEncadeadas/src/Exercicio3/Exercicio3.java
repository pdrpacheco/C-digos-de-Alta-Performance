package Exercicio3;

import java.util.Scanner;



public class Exercicio3 {

	public static void main(String[] args) {
		
		Scanner le = new Scanner(System.in);
		//cria fila de nomes
		
		int op;
		do {
			System.out.println("1-Insere paciente na fila");
			System.out.println("2- chama o paciente para atendimento");
			System.out.println("3- Encerra atendimento do dia");
			System.out.println("   Op��o:  ");
			op = le.nextInt();
			switch (op) {
			case 1:
				System.out.println("Nome do Paciente: ");
				String nome = le.next();
				fila.enqueue(nome);
				break;
			case 2:
				if (!fila.IsEmpty()) {
					System.out.println("Paciente chamado para atendimento: " +fila.dequeue());
				}
				break;
			case 3:
				if(!fila.IsEmpty()) {
					System.out.println("Ainda h� pacientes na fila");
					op = 0;
				}
				System.out.println();
				break;
			default:
				System.out.println("Op��o Inv�lida!");
			}
		}while(op!=3);
		le.close();
		System.out.println("Atendimento encerrado");

	}

}
